# FX Signal Engine

Production-ready Forex binary options signal engine based on 1-minute candle strategy with EMA, RSI, and ATR filters.

## Quick Start

```bash
npm install
cp .env.example .env
# Edit .env and add your TwelveData API key
node app.js
```

Open `http://localhost:3000` for the live dashboard.

---

## Strategy Logic

### Rule A — CALL Signal
- Previous candle is **RED** and size ≥ 100 points
- Current candle is **GREEN** and size ≤ 70 points
- Interpretation: Large bearish candle followed by small bullish = potential reversal

### Rule B — PUT Signal
- Previous candle is **RED** and size ≥ 100 points
- Current candle is **GREEN** and size ≥ 120 points
- Interpretation: Large bearish then large bullish = potential fake-out, continuation down

> **Point definition**: 1 point = 0.00001 (1/10 pip on 5-decimal pairs)

### Optional Filters (EMA + RSI + ATR)
All signals are additionally filtered by:
- **EMA 50**: Price must be above EMA50 for CALL, below for PUT
- **EMA 200**: EMA50 must be above EMA200 for CALL (trend alignment)
- **RSI 14**: Not overbought (>70) for CALL, not oversold (<30) for PUT
- **ATR 14**: Sufficient market volatility (>30 points)

60% of filter checks must pass for signal to be emitted.

### Loss Recovery
- Losses tracked via `POST /outcome`
- After 2 consecutive losses: engine skips next signal and waits for fresh confirmation
- State is per-pair, resets on a win

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/` | Live dashboard |
| GET | `/signals` | All signals (last 50) |
| GET | `/signals?pair=EURUSD` | Filter by pair |
| GET | `/signals?signal=CALL` | Filter by direction |
| GET | `/signals?limit=10` | Limit results |
| GET | `/indicators` | Latest indicator values per pair |
| GET | `/health` | Engine health check |
| POST | `/outcome` | Report trade result for loss recovery |

### Signal Response Format
```json
[
  {
    "pair": "EURUSD",
    "signal": "CALL",
    "expiry": "1m",
    "time": "2026-03-13T12:01:00Z",
    "confidence": 85,
    "indicators": {
      "ema50": 1.08423,
      "ema200": 1.08391,
      "rsi14": 52.3,
      "atr14": 0.00042
    },
    "candles": {
      "prev": { "open": 1.08500, "close": 1.08380, "size_points": 120, "color": "RED" },
      "curr": { "open": 1.08380, "close": 1.08420, "size_points": 40, "color": "GREEN" }
    }
  }
]
```

### Report Trade Outcome
```bash
curl -X POST http://localhost:3000/outcome \
  -H "Content-Type: application/json" \
  -d '{"pair": "EURUSD", "result": "win"}'
```

---

## Deploy to Render

### Option 1 — render.yaml (recommended)
1. Push repo to GitHub
2. Go to [render.com](https://render.com) → New → Blueprint
3. Connect your GitHub repo
4. Render will detect `render.yaml` automatically
5. Set `TWELVE_DATA_API_KEY` in Environment Variables
6. Deploy

### Option 2 — Manual
1. Go to render.com → New → Web Service
2. Connect GitHub repo
3. Set:
   - **Build Command**: `npm install`
   - **Start Command**: `node app.js`
   - **Node Version**: 22
4. Add Environment Variable: `TWELVE_DATA_API_KEY=your_key`
5. Deploy

### Free Tier Note
Render's free tier spins down after 15 minutes of inactivity. Use a cron service (cron-job.org) to ping `/health` every 10 minutes to keep it alive.

---

## TwelveData API

1. Sign up at [twelvedata.com](https://twelvedata.com)
2. Free plan: 800 API credits/day, 8 requests/minute
3. Each poll uses 5 requests (one per pair) — 60s interval = 5 req/min ✅
4. Add key to `.env` as `TWELVE_DATA_API_KEY`

---

## Project Structure

```
forex-signal-engine/
├── app.js          # Complete engine + API server
├── package.json
├── render.yaml     # Render deployment config
├── .env.example
├── .env            # Your keys (gitignored)
└── public/
    └── index.html  # Live signal dashboard
```

---

## Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `TWELVE_DATA_API_KEY` | ✅ Yes | — | TwelveData API key |
| `PORT` | No | 3000 | Server port (auto-set by Render) |
