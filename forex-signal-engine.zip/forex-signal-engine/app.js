'use strict';

require('dotenv').config();
const express = require('express');
const axios = require('axios');
const path = require('path');

// ─── Config ───────────────────────────────────────────────────────────────────

const PORT = process.env.PORT || 3000;
const TWELVE_DATA_API_KEY = process.env.TWELVE_DATA_API_KEY || '';
const POLL_INTERVAL_MS = 60_000;

const PAIRS = ['EUR/USD', 'GBP/USD', 'AUD/USD', 'USD/CHF', 'EUR/GBP'];
const PAIR_LABELS = {
  'EUR/USD': 'EURUSD',
  'GBP/USD': 'GBPUSD',
  'AUD/USD': 'AUDUSD',
  'USD/CHF': 'USDCHF',
  'EUR/GBP': 'EURGBP',
};

// Strategy thresholds (in points — 5-decimal pairs: 1 pip = 0.0001 = 10 points)
// Adjusted for realistic forex 1-min candle sizes:
// 100 points = 0.0010, 70 points = 0.0007, 120 points = 0.0012
const POINTS_TO_PRICE = 0.00001; // 1 point = 0.00001 (1/10 pip)
const LARGE_RED_MIN   = 100 * POINTS_TO_PRICE; // 0.001
const CALL_GREEN_MAX  = 70  * POINTS_TO_PRICE; // 0.0007
const PUT_GREEN_MIN   = 120 * POINTS_TO_PRICE; // 0.0012

// ─── State ────────────────────────────────────────────────────────────────────

/** @type {Map<string, { signal: string, time: string }[]>} loss recovery state */
const lossState = new Map(); // pair => array of recent trade outcomes

/** @type {Array} last 50 signals */
const signalHistory = [];

/** @type {Map<string, string>} pair => last processed candle open time (dedup) */
const lastProcessedCandle = new Map();

/** @type {Map<string, object>} pair => latest indicators */
const indicatorCache = new Map();

// ─── Utility helpers ──────────────────────────────────────────────────────────

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function toPoints(priceSize) {
  return Math.round(priceSize / POINTS_TO_PRICE);
}

function iso(date = new Date()) {
  return date.toISOString();
}

function log(msg) {
  console.log(`[${iso()}] ${msg}`);
}

// ─── TwelveData API ───────────────────────────────────────────────────────────

const BASE_URL = 'https://api.twelvedata.com';

async function fetchCandles(pair, limit = 52) {
  const url = `${BASE_URL}/time_series`;
  const params = {
    symbol: pair,
    interval: '1min',
    outputsize: limit,
    apikey: TWELVE_DATA_API_KEY,
    format: 'JSON',
  };

  const { data } = await axios.get(url, { params, timeout: 15_000 });

  if (data.status === 'error') {
    throw new Error(`TwelveData error for ${pair}: ${data.message}`);
  }

  if (!Array.isArray(data.values)) {
    throw new Error(`Unexpected response shape for ${pair}`);
  }

  // API returns newest-first — reverse to chronological order
  return data.values.reverse().map((v) => ({
    time: v.datetime,
    open:  parseFloat(v.open),
    high:  parseFloat(v.high),
    low:   parseFloat(v.low),
    close: parseFloat(v.close),
    volume: parseFloat(v.volume ?? 0),
  }));
}

// ─── Technical Indicators ─────────────────────────────────────────────────────

function calcEMA(closes, period) {
  if (closes.length < period) return null;
  const k = 2 / (period + 1);
  let ema = closes.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < closes.length; i++) {
    ema = closes[i] * k + ema * (1 - k);
  }
  return ema;
}

function calcRSI(closes, period = 14) {
  if (closes.length < period + 1) return null;
  const diffs = closes.slice(1).map((c, i) => c - closes[i]);
  let avgGain = 0, avgLoss = 0;
  diffs.slice(0, period).forEach((d) => {
    if (d > 0) avgGain += d;
    else avgLoss += Math.abs(d);
  });
  avgGain /= period;
  avgLoss /= period;
  for (let i = period; i < diffs.length; i++) {
    const g = diffs[i] > 0 ? diffs[i] : 0;
    const l = diffs[i] < 0 ? Math.abs(diffs[i]) : 0;
    avgGain = (avgGain * (period - 1) + g) / period;
    avgLoss = (avgLoss * (period - 1) + l) / period;
  }
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return Math.round((100 - 100 / (1 + rs)) * 100) / 100;
}

function calcATR(candles, period = 14) {
  if (candles.length < period + 1) return null;
  const trs = candles.slice(1).map((c, i) => {
    const prev = candles[i];
    return Math.max(
      c.high - c.low,
      Math.abs(c.high - prev.close),
      Math.abs(c.low - prev.close)
    );
  });
  let atr = trs.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < trs.length; i++) {
    atr = (atr * (period - 1) + trs[i]) / period;
  }
  return atr;
}

function computeIndicators(candles) {
  const closes = candles.map((c) => c.close);
  return {
    ema50:  calcEMA(closes, 50),
    ema200: calcEMA(closes, 200),
    rsi14:  calcRSI(closes, 14),
    atr14:  calcATR(candles, 14),
  };
}

// ─── Filter Logic ─────────────────────────────────────────────────────────────

function passesFilters(signal, currentCandle, indicators) {
  const { ema50, ema200, rsi14, atr14 } = indicators;
  const price = currentCandle.close;

  // Require at least some indicators to be available
  if (!ema50 || !rsi14) return { pass: true, reason: 'insufficient_data' };

  const checks = [];

  // Trend filter: price relative to EMA50
  if (signal === 'CALL') {
    checks.push({ name: 'price_above_ema50', pass: price > ema50 });
  } else {
    checks.push({ name: 'price_below_ema50', pass: price < ema50 });
  }

  // EMA trend alignment (EMA50 vs EMA200)
  if (ema200) {
    if (signal === 'CALL') {
      checks.push({ name: 'ema50_above_ema200', pass: ema50 > ema200 });
    } else {
      checks.push({ name: 'ema50_below_ema200', pass: ema50 < ema200 });
    }
  }

  // RSI filter
  if (signal === 'CALL') {
    checks.push({ name: 'rsi_not_overbought', pass: rsi14 < 70 });
    checks.push({ name: 'rsi_above_30', pass: rsi14 > 30 });
  } else {
    checks.push({ name: 'rsi_not_oversold', pass: rsi14 > 30 });
    checks.push({ name: 'rsi_below_70', pass: rsi14 < 70 });
  }

  // ATR filter: ensure sufficient volatility
  if (atr14) {
    checks.push({ name: 'atr_active', pass: atr14 > POINTS_TO_PRICE * 30 });
  }

  const passed = checks.filter((c) => c.pass).length;
  const total  = checks.length;
  const passRate = total > 0 ? passed / total : 1;

  return {
    pass: passRate >= 0.6,
    passRate,
    checks,
  };
}

// ─── Confidence Score ─────────────────────────────────────────────────────────

function computeConfidence(signal, prevCandle, currCandle, indicators) {
  let score = 50;
  const { ema50, ema200, rsi14, atr14 } = indicators;
  const price = currCandle.close;
  const prevSize = Math.abs(prevCandle.close - prevCandle.open);
  const currSize = Math.abs(currCandle.close - currCandle.open);

  // Candle size strength
  if (toPoints(prevSize) >= 150) score += 8;
  if (toPoints(prevSize) >= 200) score += 5;

  if (signal === 'CALL' && toPoints(currSize) <= 40) score += 7;
  if (signal === 'PUT'  && toPoints(currSize) >= 150) score += 7;

  // EMA alignment
  if (ema50 && ema200) {
    if (signal === 'CALL' && price > ema50 && ema50 > ema200) score += 12;
    if (signal === 'PUT'  && price < ema50 && ema50 < ema200) score += 12;
    if (signal === 'CALL' && price > ema50) score += 6;
    if (signal === 'PUT'  && price < ema50) score += 6;
  } else if (ema50) {
    if (signal === 'CALL' && price > ema50) score += 8;
    if (signal === 'PUT'  && price < ema50) score += 8;
  }

  // RSI
  if (rsi14) {
    if (signal === 'CALL' && rsi14 >= 40 && rsi14 <= 60) score += 5;
    if (signal === 'PUT'  && rsi14 >= 40 && rsi14 <= 60) score += 5;
    if (signal === 'CALL' && rsi14 > 60) score -= 5;
    if (signal === 'PUT'  && rsi14 < 40) score -= 5;
  }

  // ATR volatility
  if (atr14 && atr14 > POINTS_TO_PRICE * 50) score += 5;

  return Math.min(98, Math.max(45, score));
}

// ─── Loss Recovery State ──────────────────────────────────────────────────────

function getLossRecoveryState(pair) {
  return lossState.get(pair) || [];
}

function shouldSkipDueToLoss(pair) {
  const state = getLossRecoveryState(pair);
  // If 2 consecutive losses, skip
  if (state.length >= 2 && state.slice(-2).every((s) => s === 'loss')) {
    return true;
  }
  return false;
}

/**
 * Simulate outcome: in real usage you'd feed back actual trade results.
 * Here we probabilistically mark win/loss (for demo purposes).
 */
function recordTradeOutcome(pair, signal) {
  // In production: hook into a broker callback
  // For demo: we'll record as pending and let external POST /outcome update it
  const state = getLossRecoveryState(pair);
  state.push('pending');
  lossState.set(pair, state.slice(-3));
}

// ─── Signal Generation ────────────────────────────────────────────────────────

function generateSignal(pair, candles) {
  if (candles.length < 2) return null;

  const prev = candles[candles.length - 2];
  const curr = candles[candles.length - 1];

  // Dedup: skip if we already processed this candle
  const pairLabel = PAIR_LABELS[pair] || pair;
  const candleKey = `${pairLabel}-${curr.time}`;
  if (lastProcessedCandle.get(pairLabel) === curr.time) {
    return null;
  }

  const prevSize = Math.abs(prev.close - prev.open);
  const currSize = Math.abs(curr.close - curr.open);
  const prevIsRed   = prev.close < prev.open;
  const currIsGreen = curr.close > curr.open;

  let signal = null;

  // Rule A: Large red → small green = CALL (reversal)
  if (prevIsRed && prevSize >= LARGE_RED_MIN && currIsGreen && currSize <= CALL_GREEN_MAX) {
    signal = 'CALL';
  }

  // Rule B: Large red → large green = PUT (continuation/fake breakout)
  if (!signal && prevIsRed && prevSize >= LARGE_RED_MIN && currIsGreen && currSize >= PUT_GREEN_MIN) {
    signal = 'PUT';
  }

  if (!signal) return null;

  // Compute indicators
  const indicators = computeIndicators(candles);
  indicatorCache.set(pairLabel, indicators);

  // Apply filters
  const filter = passesFilters(signal, curr, indicators);
  if (!filter.pass) {
    log(`[FILTERED] ${pairLabel} ${signal} — filters not met (rate: ${(filter.passRate * 100).toFixed(0)}%)`);
    return null;
  }

  // Loss recovery check
  if (shouldSkipDueToLoss(pairLabel)) {
    log(`[SKIPPED] ${pairLabel} ${signal} — waiting for confirmation after 2 losses`);
    return null;
  }

  const confidence = computeConfidence(signal, prev, curr, indicators);

  // Mark candle as processed
  lastProcessedCandle.set(pairLabel, curr.time);

  const entry = {
    pair:       pairLabel,
    signal,
    expiry:     '1m',
    time:       new Date(curr.time).toISOString(),
    confidence,
    indicators: {
      ema50:  indicators.ema50  ? +indicators.ema50.toFixed(5)  : null,
      ema200: indicators.ema200 ? +indicators.ema200.toFixed(5) : null,
      rsi14:  indicators.rsi14  ? +indicators.rsi14.toFixed(2)  : null,
      atr14:  indicators.atr14  ? +indicators.atr14.toFixed(5)  : null,
    },
    candles: {
      prev: {
        open:  prev.open,
        close: prev.close,
        size_points: toPoints(prevSize),
        color: 'RED',
      },
      curr: {
        open:  curr.open,
        close: curr.close,
        size_points: toPoints(currSize),
        color: 'GREEN',
      },
    },
  };

  log(`[SIGNAL] ${pairLabel} ${signal} @ ${entry.time} | Confidence: ${confidence}% | RSI: ${indicators.rsi14?.toFixed(1)} | ATR: ${indicators.atr14?.toFixed(5)}`);

  // Record for loss recovery
  recordTradeOutcome(pairLabel, signal);

  return entry;
}

// ─── Engine Loop ──────────────────────────────────────────────────────────────

async function processPair(pair) {
  try {
    const candles = await fetchCandles(pair, 210); // 210 candles for EMA200
    const signal  = generateSignal(pair, candles);

    if (signal) {
      signalHistory.unshift(signal);
      if (signalHistory.length > 50) signalHistory.pop();
    }
  } catch (err) {
    log(`[ERROR] ${pair}: ${err.message}`);
  }
}

async function runEngine() {
  log('[ENGINE] Starting signal engine...');
  log(`[ENGINE] Monitoring: ${PAIRS.join(', ')}`);
  log(`[ENGINE] Poll interval: ${POLL_INTERVAL_MS / 1000}s`);

  const tick = async () => {
    log('[ENGINE] Polling market data...');
    for (const pair of PAIRS) {
      await processPair(pair);
      await sleep(500); // small delay between API calls
    }
  };

  await tick(); // immediate first run
  setInterval(tick, POLL_INTERVAL_MS);
}

// ─── Express Server ───────────────────────────────────────────────────────────

const app = express();
app.use(express.json());

// Serve dashboard
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Main signals endpoint
app.get('/signals', (req, res) => {
  const { pair, signal, limit = 50 } = req.query;
  let results = [...signalHistory];
  if (pair)   results = results.filter((s) => s.pair === pair.toUpperCase());
  if (signal) results = results.filter((s) => s.signal === signal.toUpperCase());
  res.json(results.slice(0, parseInt(limit, 10)));
});

// Health check
app.get('/health', (req, res) => {
  res.json({
    status:  'ok',
    uptime:  process.uptime(),
    signals: signalHistory.length,
    pairs:   PAIRS.map(PAIR_LABELS),
    time:    iso(),
  });
});

// Indicator snapshot
app.get('/indicators', (req, res) => {
  const result = {};
  indicatorCache.forEach((v, k) => { result[k] = v; });
  res.json(result);
});

// POST /outcome — feed back trade result for loss recovery
app.post('/outcome', (req, res) => {
  const { pair, result } = req.body; // result: 'win' | 'loss'
  if (!pair || !['win', 'loss'].includes(result)) {
    return res.status(400).json({ error: 'pair and result (win|loss) required' });
  }
  const state = getLossRecoveryState(pair.toUpperCase());
  // Replace last 'pending' with actual result
  const pendingIdx = state.lastIndexOf('pending');
  if (pendingIdx !== -1) state[pendingIdx] = result;
  lossState.set(pair.toUpperCase(), state.slice(-3));
  res.json({ pair: pair.toUpperCase(), state });
});

// ─── Start ────────────────────────────────────────────────────────────────────

app.listen(PORT, async () => {
  log(`[SERVER] Listening on port ${PORT}`);
  if (!TWELVE_DATA_API_KEY) {
    log('[WARN] TWELVE_DATA_API_KEY not set — API calls will fail');
  }
  await runEngine();
});

module.exports = app;
